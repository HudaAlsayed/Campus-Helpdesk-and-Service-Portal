import { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { getFaqs, searchFaqs, type FAQ as FAQType, FAQ_CATEGORIES } from "@/lib/faqData";
import { cn } from "@/lib/utils";

const FAQ = () => {
  const [faqs, setFaqs] = useState<FAQType[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  useEffect(() => {
    setFaqs(getFaqs());
  }, []);

  const filteredFaqs = useMemo(() => {
    let result = faqs;
    if (selectedCategory !== "All") {
      result = result.filter((f) => f.category === selectedCategory);
    }
    if (searchQuery.trim()) {
      result = searchFaqs(searchQuery, result);
    }
    return result;
  }, [faqs, searchQuery, selectedCategory]);

  return (
    <main className="min-h-screen py-12 px-4">
      <div className="container mx-auto max-w-3xl">
        <div className="text-center mb-8 animate-fade-in">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Frequently Asked Questions
          </h1>
          <p className="text-muted-foreground">
            Find quick answers to common questions about campus services.
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative mb-6 animate-fade-in" style={{ animationDelay: "0.1s" }}>
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search FAQs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2 mb-8 animate-fade-in" style={{ animationDelay: "0.15s" }}>
          {FAQ_CATEGORIES.map((cat) => (
            <Button
              key={cat}
              variant={selectedCategory === cat ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(cat)}
              className={cn(
                selectedCategory === cat && "bg-accent hover:bg-accent/90"
              )}
            >
              {cat}
            </Button>
          ))}
        </div>

        {/* FAQ List */}
        {filteredFaqs.length > 0 ? (
          <Accordion type="single" collapsible className="space-y-4">
            {filteredFaqs.map((faq, index) => (
              <AccordionItem
                key={faq.id}
                value={faq.id}
                className="bg-card rounded-lg border border-border px-6 animate-fade-in"
                style={{ animationDelay: `${0.05 * index}s` }}
              >
                <AccordionTrigger className="text-left font-medium hover:text-accent">
                  <div className="flex flex-col items-start gap-1">
                    <span>{faq.question}</span>
                    <span className="text-xs text-muted-foreground font-normal">
                      {faq.category}
                    </span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            No FAQs found matching your search.
          </div>
        )}

        {/* Still Need Help */}
        <div
          className="mt-12 text-center p-6 bg-card rounded-lg border border-border animate-fade-in"
          style={{ animationDelay: "0.4s" }}
        >
          <p className="text-foreground font-medium mb-2">Still need help?</p>
          <p className="text-muted-foreground text-sm mb-4">
            Submit a ticket and our support team will get back to you within 24 hours.
          </p>
          <Button asChild className="bg-accent hover:bg-accent/90">
            <Link to="/tickets">Submit a Ticket</Link>
          </Button>
        </div>
      </div>
    </main>
  );
};

export default FAQ;
