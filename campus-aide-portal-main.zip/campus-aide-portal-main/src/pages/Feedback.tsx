import { useState } from "react";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const Feedback = () => {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (rating === 0) {
      toast({
        title: "Rating Required",
        description: "Please select a rating before submitting.",
        variant: "destructive",
      });
      return;
    }

    const userRole = localStorage.getItem("userRole") || "guest";
    
    const feedbackEntry = {
      id: Date.now(),
      role: userRole,
      rating,
      comment: comment.trim(),
      createdAt: new Date().toISOString(),
    };

    const existingFeedback = JSON.parse(localStorage.getItem("chsp_feedback") || "[]");
    existingFeedback.push(feedbackEntry);
    localStorage.setItem("chsp_feedback", JSON.stringify(existingFeedback));

    toast({
      title: "Thank You!",
      description: "Your feedback has been submitted successfully.",
    });

    setRating(0);
    setComment("");
  };

  return (
    <main className="min-h-screen bg-background py-12 px-4">
      <div className="container mx-auto max-w-lg">
        <Card className="animate-fade-in">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold">Share Your Feedback</CardTitle>
            <CardDescription>
              Help us improve the Campus Helpdesk experience
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label>How would you rate your experience?</Label>
                <div className="flex justify-center gap-2 py-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoveredRating(star)}
                      onMouseLeave={() => setHoveredRating(0)}
                      className="transition-transform hover:scale-110 focus:outline-none"
                    >
                      <Star
                        size={32}
                        className={cn(
                          "transition-colors",
                          (hoveredRating || rating) >= star
                            ? "fill-accent text-accent"
                            : "text-muted-foreground"
                        )}
                      />
                    </button>
                  ))}
                </div>
                <p className="text-center text-sm text-muted-foreground">
                  {rating > 0 ? `You selected ${rating} star${rating > 1 ? "s" : ""}` : "Click to rate"}
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="comment">Additional Comments (Optional)</Label>
                <Textarea
                  id="comment"
                  placeholder="Tell us more about your experience..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={4}
                />
              </div>

              <Button type="submit" className="w-full bg-accent hover:bg-accent/90">
                Submit Feedback
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </main>
  );
};

export default Feedback;
