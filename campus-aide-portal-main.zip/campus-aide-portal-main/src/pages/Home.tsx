import { Link } from "react-router-dom";
import { HelpCircle, Ticket, Shield, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import FeatureCard from "@/components/FeatureCard";

const features = [
  {
    title: "FAQ",
    description: "Find instant answers to commonly asked questions about campus services and policies.",
    icon: HelpCircle,
    link: "/faq",
  },
  {
    title: "Tickets",
    description: "Submit and track your support requests. Get help from our dedicated team.",
    icon: Ticket,
    link: "/tickets",
  },
  {
    title: "Admin Portal",
    description: "Manage tickets, users, and system settings. For authorized personnel only.",
    icon: Shield,
    link: "/admin",
  },
  {
    title: "Chatbot",
    description: "Get instant AI-powered assistance 24/7 for common inquiries and guidance.",
    icon: MessageCircle,
    link: "/faq",
  },
];

const Home = () => {
  return (
    <main className="min-h-screen">
      {/* Hero Section with Logo Watermark */}
      <section className="relative bg-primary text-primary-foreground py-20 px-4 overflow-hidden">
        {/* Logo watermark background */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: "url('/logo.png')",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "center",
            backgroundSize: "contain",
          }}
        />
        {/* Dark overlay for readability */}
        <div className="absolute inset-0 bg-primary/40" />
        
        <div className="relative container mx-auto text-center max-w-3xl z-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 animate-fade-in">
            Campus Helpdesk & Service Portal
          </h1>
          <p className="text-lg md:text-xl text-primary-foreground/80 mb-8 animate-fade-in" style={{ animationDelay: "0.1s" }}>
            Your one-stop solution for campus support, FAQs, and service requests. 
            We're here to help you succeed.
          </p>
          <div className="flex flex-wrap justify-center gap-4 animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <Button asChild size="lg" variant="secondary">
              <Link to="/faq">Browse FAQ</Link>
            </Button>
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
              <Link to="/tickets">Submit Ticket</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10">
              <Link to="/login">Sign In</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12 text-foreground">
            How Can We Help You?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div 
                key={feature.title} 
                className="animate-fade-in" 
                style={{ animationDelay: `${0.1 * (index + 1)}s` }}
              >
                <FeatureCard {...feature} />
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
};

export default Home;
