import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Ticket, Users, Clock, CheckCircle, Plus, Pencil, Trash2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getFaqs, addFaq, updateFaq, deleteFaq, FAQ, FAQ_CATEGORIES } from "@/lib/faqData";

interface TicketStats {
  total: number;
  open: number;
  pending: number;
  closed: number;
}

const getTicketStats = (): TicketStats => {
  const stored = localStorage.getItem("chsp_tickets");
  if (!stored) return { total: 0, open: 0, pending: 0, closed: 0 };
  const tickets = JSON.parse(stored);
  return {
    total: tickets.length,
    open: tickets.filter((t: { status: string }) => t.status === "Open").length,
    pending: tickets.filter((t: { status: string }) => t.status === "Pending").length,
    closed: tickets.filter((t: { status: string }) => t.status === "Closed").length,
  };
};

type FAQCategory = FAQ["category"];

const Admin = () => {
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [ticketStats, setTicketStats] = useState<TicketStats>(getTicketStats());
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingFaq, setEditingFaq] = useState<FAQ | null>(null);
  const [formQuestion, setFormQuestion] = useState("");
  const [formAnswer, setFormAnswer] = useState("");
  const [formCategory, setFormCategory] = useState<FAQCategory>("IT");
  const { toast } = useToast();

  useEffect(() => {
    setFaqs(getFaqs());
    setTicketStats(getTicketStats());
  }, []);

  const refreshStats = () => {
    setTicketStats(getTicketStats());
    toast({ title: "Stats Refreshed", description: "Ticket statistics have been updated." });
  };

  const resetForm = () => {
    setFormQuestion("");
    setFormAnswer("");
    setFormCategory("IT");
    setEditingFaq(null);
  };

  const openAddDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (faq: FAQ) => {
    setEditingFaq(faq);
    setFormQuestion(faq.question);
    setFormAnswer(faq.answer);
    setFormCategory(faq.category);
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formQuestion.trim() || !formAnswer.trim()) {
      toast({ title: "Error", description: "Please fill all fields.", variant: "destructive" });
      return;
    }

    if (editingFaq) {
      updateFaq(editingFaq.id, {
        question: formQuestion.trim(),
        answer: formAnswer.trim(),
        category: formCategory,
      });
      toast({ title: "FAQ Updated", description: "The FAQ has been updated." });
    } else {
      addFaq({
        question: formQuestion.trim(),
        answer: formAnswer.trim(),
        category: formCategory,
      });
      toast({ title: "FAQ Added", description: "A new FAQ has been added." });
    }

    setFaqs(getFaqs());
    setDialogOpen(false);
    resetForm();
  };

  const handleDelete = (id: string) => {
    deleteFaq(id);
    setFaqs(getFaqs());
    toast({ title: "FAQ Deleted", description: "The FAQ has been removed." });
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      IT: "bg-accent text-accent-foreground",
      Registration: "bg-purple-600 text-white",
      Finance: "bg-green-600 text-white",
      Library: "bg-yellow-600 text-white",
      Housing: "bg-orange-600 text-white",
    };
    return colors[category] || "bg-muted text-muted-foreground";
  };

  return (
    <main className="min-h-screen py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="mb-8 animate-fade-in">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground">
            Manage tickets, FAQs, and system settings.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Ticket Statistics</h2>
          <Button variant="outline" size="sm" onClick={refreshStats}>
            <RefreshCw className="w-4 h-4 mr-2" /> Refresh Stats
          </Button>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="animate-fade-in" style={{ animationDelay: "0.1s" }}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Tickets</p>
                  <p className="text-2xl font-bold text-foreground">{ticketStats.total}</p>
                </div>
                <Ticket className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>
          <Card className="animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Open</p>
                  <p className="text-2xl font-bold text-foreground">{ticketStats.open}</p>
                </div>
                <Clock className="w-8 h-8 text-accent" />
              </div>
            </CardContent>
          </Card>
          <Card className="animate-fade-in" style={{ animationDelay: "0.3s" }}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending</p>
                  <p className="text-2xl font-bold text-foreground">{ticketStats.pending}</p>
                </div>
                <Users className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>
          <Card className="animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Closed</p>
                  <p className="text-2xl font-bold text-foreground">{ticketStats.closed}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Management */}
        <Card className="animate-fade-in" style={{ animationDelay: "0.4s" }}>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>FAQ Management</CardTitle>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={openAddDialog} className="bg-accent hover:bg-accent/90">
                  <Plus className="w-4 h-4 mr-2" /> Add FAQ
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingFaq ? "Edit FAQ" : "Add New FAQ"}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label>Question</Label>
                    <Input
                      value={formQuestion}
                      onChange={(e) => setFormQuestion(e.target.value)}
                      placeholder="Enter question"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Answer</Label>
                    <Textarea
                      value={formAnswer}
                      onChange={(e) => setFormAnswer(e.target.value)}
                      placeholder="Enter answer"
                      rows={4}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select value={formCategory} onValueChange={(v) => setFormCategory(v as FAQCategory)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {FAQ_CATEGORIES.filter((c) => c !== "All").map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleSave} className="w-full bg-accent hover:bg-accent/90">
                    {editingFaq ? "Update FAQ" : "Add FAQ"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {faqs.map((faq) => (
                <div
                  key={faq.id}
                  className="flex items-start justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex-1 mr-4">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge className={getCategoryColor(faq.category)}>{faq.category}</Badge>
                    </div>
                    <p className="font-medium text-foreground">{faq.question}</p>
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                      {faq.answer}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => openEditDialog(faq)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleDelete(faq.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
};

export default Admin;
