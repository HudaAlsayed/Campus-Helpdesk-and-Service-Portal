import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getFaqs, findFaqByKeywords } from "@/lib/faqData";
import { cn } from "@/lib/utils";

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  relatedQuestion?: string;
}

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hi! I'm the Campus Helpdesk assistant. Ask me anything about campus services!",
      isBot: true,
    },
  ]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    const trimmed = input.trim();
    if (!trimmed) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      text: trimmed,
      isBot: false,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");

    setTimeout(() => {
      const faqs = getFaqs();
      const match = findFaqByKeywords(trimmed, faqs);

      let botMsg: Message;
      if (match) {
        botMsg = {
          id: (Date.now() + 1).toString(),
          text: match.answer,
          isBot: true,
          relatedQuestion: match.question,
        };
      } else {
        botMsg = {
          id: (Date.now() + 1).toString(),
          text: "I couldn't find an answer to that. Try checking the FAQ page or submit a support ticket for further assistance.",
          isBot: true,
        };
      }
      setMessages((prev) => [...prev, botMsg]);
    }, 500);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition-all duration-300",
          isOpen
            ? "bg-muted text-foreground"
            : "bg-accent text-accent-foreground hover:scale-105"
        )}
        aria-label={isOpen ? "Close chatbot" : "Open chatbot"}
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-80 sm:w-96 bg-card border border-border rounded-lg shadow-xl flex flex-col animate-fade-in overflow-hidden">
          {/* Header */}
          <div className="bg-primary text-primary-foreground p-4">
            <h3 className="font-semibold">Campus Helpdesk Bot</h3>
            <p className="text-xs text-primary-foreground/70">Ask me about campus services</p>
          </div>

          {/* Messages */}
          <div className="flex-1 p-4 space-y-3 max-h-80 overflow-y-auto">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={cn(
                  "max-w-[85%] p-3 rounded-lg text-sm",
                  msg.isBot
                    ? "bg-muted text-foreground"
                    : "bg-accent text-accent-foreground ml-auto"
                )}
              >
                {msg.text}
                {msg.relatedQuestion && (
                  <p className="mt-2 text-xs opacity-70 border-t border-border/50 pt-2">
                    Related: {msg.relatedQuestion}
                  </p>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t border-border flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your question..."
              className="flex-1"
            />
            <Button
              onClick={handleSend}
              size="icon"
              className="bg-accent hover:bg-accent/90"
              disabled={!input.trim()}
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;
