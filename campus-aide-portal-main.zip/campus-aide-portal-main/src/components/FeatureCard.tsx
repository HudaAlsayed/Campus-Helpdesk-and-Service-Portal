import { LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

interface FeatureCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  link: string;
}

const FeatureCard = ({ title, description, icon: Icon, link }: FeatureCardProps) => {
  return (
    <Link
      to={link}
      className="group bg-card rounded-lg p-6 shadow-sm border border-border card-hover block"
    >
      <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
        <Icon className="w-6 h-6 text-accent" />
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
    </Link>
  );
};

export default FeatureCard;
