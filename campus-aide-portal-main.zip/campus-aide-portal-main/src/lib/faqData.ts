export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: "IT" | "Registration" | "Finance" | "Library" | "Housing";
}

export const FAQ_CATEGORIES = ["All", "IT", "Registration", "Finance", "Library", "Housing"] as const;

const initialFaqs: FAQ[] = [
  { id: "1", question: "How do I reset my campus password?", answer: "Visit the IT Self-Service Portal at portal.campus.edu and click 'Forgot Password'. You'll receive a reset link to your registered email address within 5 minutes.", category: "IT" },
  { id: "2", question: "How do I connect to campus WiFi?", answer: "Select 'Campus-Secure' from available networks. Use your campus email as username and your student portal password. For guests, connect to 'Campus-Guest' and register with your email.", category: "IT" },
  { id: "3", question: "How do I install licensed software?", answer: "Visit software.campus.edu and log in with your student credentials. Browse available software, click 'Download', and follow the installation instructions provided.", category: "IT" },
  { id: "4", question: "How do I register for classes?", answer: "Log into the Student Portal during your designated registration window. Navigate to 'Course Registration', search for classes, and add them to your schedule. Don't forget to click 'Submit Registration'.", category: "Registration" },
  { id: "5", question: "What is the deadline to add/drop courses?", answer: "The add/drop deadline is typically the end of the second week of classes. Check the Academic Calendar for exact dates. Late drops may incur a 'W' grade on your transcript.", category: "Registration" },
  { id: "6", question: "How do I declare or change my major?", answer: "Schedule an appointment with your academic advisor through the Advising Portal. Complete the Major Declaration Form and obtain required signatures from your new department.", category: "Registration" },
  { id: "7", question: "When is tuition due?", answer: "Tuition is due by the first day of classes each semester. Payment plans are available through the Bursar's Office. Late payments incur a $50 fee and may result in registration holds.", category: "Finance" },
  { id: "8", question: "How do I apply for financial aid?", answer: "Complete the FAFSA at studentaid.gov using our school code. Submit by March 1 for priority consideration. Check your student portal for any additional required documents.", category: "Finance" },
  { id: "9", question: "How do I get a refund for dropped courses?", answer: "Refunds are processed automatically based on the drop date. 100% refund during week 1, 75% during week 2, 50% during week 3. No refunds after week 3. Processing takes 2-3 weeks.", category: "Finance" },
  { id: "10", question: "What are the library operating hours?", answer: "The main library is open Monday-Friday 7am-11pm, Saturday 9am-9pm, and Sunday 10am-10pm. Extended hours (24/7) are available during finals week.", category: "Library" },
  { id: "11", question: "How do I reserve a study room?", answer: "Visit library.campus.edu/rooms and log in with your student ID. Select your preferred date, time, and room size. Rooms can be booked up to 2 weeks in advance for up to 3 hours.", category: "Library" },
  { id: "12", question: "How do I submit a housing application?", answer: "Log into the Housing Portal at housing.campus.edu. Complete the application, pay the $200 deposit, and submit your roommate preferences by April 1 for fall semester priority.", category: "Housing" },
  { id: "13", question: "How do I request a room change?", answer: "Submit a Room Change Request through the Housing Portal. Include your reason and preferred location. Requests are reviewed weekly, and you'll receive a decision within 5-7 business days.", category: "Housing" },
  { id: "14", question: "How do I report a maintenance issue in my dorm?", answer: "Log into the Housing Portal and select 'Maintenance Request'. Describe the issue, attach photos if applicable, and submit. Urgent issues (water, electricity) should be reported to your RA immediately.", category: "Housing" },
];

const STORAGE_KEY = "chsp_faqs";

export const getFaqs = (): FAQ[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(initialFaqs));
    return initialFaqs;
  }
  return JSON.parse(stored);
};

export const saveFaqs = (faqs: FAQ[]): void => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(faqs));
};

export const addFaq = (faq: Omit<FAQ, "id">): FAQ => {
  const faqs = getFaqs();
  const newFaq: FAQ = { ...faq, id: Date.now().toString() };
  saveFaqs([...faqs, newFaq]);
  return newFaq;
};

export const updateFaq = (id: string, updates: Partial<Omit<FAQ, "id">>): void => {
  const faqs = getFaqs();
  const index = faqs.findIndex((f) => f.id === id);
  if (index !== -1) {
    faqs[index] = { ...faqs[index], ...updates };
    saveFaqs(faqs);
  }
};

export const deleteFaq = (id: string): void => {
  const faqs = getFaqs().filter((f) => f.id !== id);
  saveFaqs(faqs);
};

export const searchFaqs = (query: string, faqs: FAQ[]): FAQ[] => {
  const lower = query.toLowerCase();
  return faqs.filter(
    (f) =>
      f.question.toLowerCase().includes(lower) ||
      f.answer.toLowerCase().includes(lower)
  );
};

export const findFaqByKeywords = (message: string, faqs: FAQ[]): FAQ | null => {
  const words = message.toLowerCase().split(/\s+/).filter((w) => w.length > 2);
  let bestMatch: FAQ | null = null;
  let bestScore = 0;

  for (const faq of faqs) {
    const text = (faq.question + " " + faq.answer).toLowerCase();
    let score = 0;
    for (const word of words) {
      if (text.includes(word)) score++;
    }
    if (score > bestScore && score >= 2) {
      bestScore = score;
      bestMatch = faq;
    }
  }
  return bestMatch;
};
